-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `temporada`
--

DROP TABLE IF EXISTS `temporada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporada` (
  `id_temporada` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `id_club` int(11) NOT NULL,
  `estado` enum('Abierta','Cerrada') NOT NULL DEFAULT 'Abierta',
  `fecha_inicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_cierre` datetime DEFAULT NULL,
  `id_usuario_cierre` int(11) DEFAULT NULL,
  `abierta_marca` tinyint(4) GENERATED ALWAYS AS (if((`estado` = 'Abierta'),1,NULL)) STORED,
  PRIMARY KEY (`id_temporada`),
  UNIQUE KEY `uk_una_abierta_por_club` (`id_club`,`abierta_marca`),
  KEY `fk_temporada_usuario` (`id_usuario_cierre`),
  KEY `idx_temporada_club` (`id_club`,`estado`),
  CONSTRAINT `fk_temporada_club` FOREIGN KEY (`id_club`) REFERENCES `club` (`id_club`),
  CONSTRAINT `fk_temporada_usuario` FOREIGN KEY (`id_usuario_cierre`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporada`
--

LOCK TABLES `temporada` WRITE;
/*!40000 ALTER TABLE `temporada` DISABLE KEYS */;
INSERT INTO `temporada` (`id_temporada`, `nombre`, `id_club`, `estado`, `fecha_inicio`, `fecha_cierre`, `id_usuario_cierre`) VALUES (1,'Temporada 1',4,'Cerrada','2026-11-04 20:58:16','2026-11-04 21:07:06',46),(2,'Temporada 2',4,'Cerrada','2026-11-04 21:07:06','2026-11-05 16:04:13',46),(3,'Temporada 3',4,'Cerrada','2026-11-05 16:04:13','2026-11-12 17:33:46',46),(5,'Temporada 1',6,'Cerrada','2026-11-12 12:05:09','2026-11-12 12:48:52',365),(6,'Temporada 2',6,'Cerrada','2026-11-12 12:48:52','2026-11-12 12:51:51',365),(7,'Temporada 3',6,'Cerrada','2026-11-12 12:51:51','2026-11-12 17:33:08',365),(8,'Temporada 4',6,'Abierta','2026-11-12 17:33:08',NULL,NULL),(9,'Temporada 4',4,'Abierta','2026-11-12 17:33:46',NULL,NULL);
/*!40000 ALTER TABLE `temporada` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
