-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `torneos`
--

DROP TABLE IF EXISTS `torneos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `torneos` (
  `id_torneo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fecha_inicio` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `fecha_fin` date NOT NULL,
  `hora_fin` time DEFAULT NULL,
  `lugar` varchar(100) NOT NULL,
  `id_club` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `tipo` enum('Individual','Parejas','Mixto') NOT NULL,
  `max_participantes` int(11) NOT NULL,
  `estado` enum('Abierto','Cerrado','En curso','Finalizado') NOT NULL DEFAULT 'Abierto',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_torneo`),
  KEY `fk_torneo_categoria` (`id_categoria`),
  KEY `fk_torneo_club` (`id_club`),
  CONSTRAINT `fk_torneo_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON UPDATE CASCADE,
  CONSTRAINT `fk_torneo_club` FOREIGN KEY (`id_club`) REFERENCES `club` (`id_club`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torneos`
--

LOCK TABLES `torneos` WRITE;
/*!40000 ALTER TABLE `torneos` DISABLE KEYS */;
INSERT INTO `torneos` VALUES (201,'Liga Bull · Principiante · Fecha 1',NULL,'2026-09-28','18:00:00','2026-09-29',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:32:31'),(202,'Liga Bull · Principiante · Fecha 2',NULL,'2026-09-29','18:00:00','2026-09-30',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:32:32'),(203,'Liga Bull · Principiante · Fecha 3',NULL,'2026-09-30','18:00:00','2026-10-01',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:32:34'),(204,'Liga Bull · Principiante · Fecha 4',NULL,'2026-10-02','18:00:00','2026-10-03',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:32:36'),(205,'Liga Bull · Principiante · Fecha 5',NULL,'2026-10-03','18:00:00','2026-10-04',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:32:37'),(206,'Copa Apertura Bull · 7ta',NULL,'2026-10-04','18:00:00','2026-10-05',NULL,'Sin completar',6,2,'Individual',9,'Finalizado','2026-11-12 20:32:39'),(207,'Copa Apertura Bull · 6ta',NULL,'2026-10-05','18:00:00','2026-10-06',NULL,'Sin completar',6,3,'Individual',8,'Finalizado','2026-11-12 20:32:41'),(208,'Dobles Apertura Bull · 5ta',NULL,'2026-10-07','18:00:00','2026-10-08',NULL,'Sin completar',6,4,'Parejas',8,'Finalizado','2026-11-12 20:32:42'),(209,'Copa Apertura Bull · 5ta',NULL,'2026-10-08','18:00:00','2026-10-09',NULL,'Sin completar',6,4,'Individual',8,'Finalizado','2026-11-12 20:33:00'),(210,'Copa Apertura Bull · 4ta',NULL,'2026-10-09','18:00:00','2026-10-10',NULL,'Sin completar',6,5,'Individual',8,'Finalizado','2026-11-12 20:33:02'),(211,'Copa Apertura Bull · 3ra',NULL,'2026-10-10','18:00:00','2026-10-11',NULL,'Sin completar',6,6,'Individual',8,'Finalizado','2026-11-12 20:33:03'),(212,'Copa Apertura Bull · 2da',NULL,'2026-10-12','18:00:00','2026-10-13',NULL,'Sin completar',6,7,'Individual',8,'Finalizado','2026-11-12 20:33:05'),(213,'Copa Apertura Bull · 1ra',NULL,'2026-10-13','18:00:00','2026-10-14',NULL,'Sin completar',6,8,'Individual',8,'Finalizado','2026-11-12 20:33:07'),(214,'Liga hola padel · Principiante · Fecha 1',NULL,'2026-09-28','18:00:00','2026-09-29',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:33:08'),(215,'Liga hola padel · Principiante · Fecha 2',NULL,'2026-09-29','18:00:00','2026-09-30',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:33:10'),(216,'Liga hola padel · Principiante · Fecha 3',NULL,'2026-09-30','18:00:00','2026-10-01',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:33:12'),(217,'Liga hola padel · Principiante · Fecha 4',NULL,'2026-10-02','18:00:00','2026-10-03',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:33:13'),(218,'Liga hola padel · Principiante · Fecha 5',NULL,'2026-10-03','18:00:00','2026-10-04',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:33:15'),(219,'Copa Apertura hola padel · 7ta',NULL,'2026-10-04','18:00:00','2026-10-05',NULL,'Isla Malvinas',4,2,'Individual',9,'Finalizado','2026-11-12 20:33:17'),(220,'Copa Apertura hola padel · 6ta',NULL,'2026-10-05','18:00:00','2026-10-06',NULL,'Isla Malvinas',4,3,'Individual',8,'Finalizado','2026-11-12 20:33:19'),(221,'Copa Apertura hola padel · 5ta',NULL,'2026-10-07','18:00:00','2026-10-08',NULL,'Isla Malvinas',4,4,'Individual',8,'Finalizado','2026-11-12 20:33:20'),(222,'Dobles Apertura hola padel · 4ta',NULL,'2026-10-08','18:00:00','2026-10-09',NULL,'Isla Malvinas',4,5,'Parejas',8,'Finalizado','2026-11-12 20:33:22'),(223,'Copa Apertura hola padel · 4ta',NULL,'2026-10-09','18:00:00','2026-10-10',NULL,'Isla Malvinas',4,5,'Individual',8,'Finalizado','2026-11-12 20:33:39'),(224,'Copa Apertura hola padel · 3ra',NULL,'2026-10-10','18:00:00','2026-10-11',NULL,'Isla Malvinas',4,6,'Individual',8,'Finalizado','2026-11-12 20:33:41'),(225,'Copa Apertura hola padel · 2da',NULL,'2026-10-12','18:00:00','2026-10-13',NULL,'Isla Malvinas',4,7,'Individual',8,'Finalizado','2026-11-12 20:33:43'),(226,'Copa Apertura hola padel · 1ra',NULL,'2026-10-13','18:00:00','2026-10-14',NULL,'Isla Malvinas',4,8,'Individual',8,'Finalizado','2026-11-12 20:33:44'),(227,'Copa Primavera Bull · Principiante',NULL,'2026-10-22','18:00:00','2026-10-23',NULL,'Sin completar',6,1,'Individual',8,'Finalizado','2026-11-12 20:33:46'),(228,'Copa Primavera Bull · 7ta',NULL,'2026-10-24','18:00:00','2026-10-25',NULL,'Sin completar',6,2,'Individual',9,'Finalizado','2026-11-12 20:33:48'),(229,'Copa Primavera Bull · 6ta',NULL,'2026-10-26','18:00:00','2026-10-27',NULL,'Sin completar',6,3,'Individual',8,'Finalizado','2026-11-12 20:33:50'),(230,'Copa Primavera Bull · 5ta',NULL,'2026-10-29','18:00:00','2026-10-30',NULL,'Sin completar',6,4,'Individual',8,'Finalizado','2026-11-12 20:33:51'),(231,'Copa Primavera Bull · 4ta',NULL,'2026-10-31','18:00:00','2026-11-01',NULL,'Sin completar',6,5,'Individual',8,'Finalizado','2026-11-12 20:33:53'),(232,'Copa Primavera Bull · 3ra',NULL,'2026-11-02','18:00:00','2026-11-03',NULL,'Sin completar',6,6,'Individual',8,'Finalizado','2026-11-12 20:33:55'),(233,'Copa Primavera Bull · 2da',NULL,'2026-11-04','18:00:00','2026-11-05',NULL,'Sin completar',6,7,'Individual',8,'Finalizado','2026-11-12 20:33:56'),(234,'Copa Primavera Bull · 1ra',NULL,'2026-11-07','18:00:00','2026-11-08',NULL,'Sin completar',6,8,'Individual',7,'Finalizado','2026-11-12 20:33:58'),(235,'Dobles Primavera Bull · Principiante',NULL,'2026-11-09','18:00:00','2026-11-10',NULL,'Sin completar',6,1,'Parejas',8,'Finalizado','2026-11-12 20:33:59'),(236,'Gran Premio Bull · 4ta',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Sin completar',6,5,'Individual',8,'En curso','2026-11-12 20:34:17'),(237,'Gran Premio Bull · 3ra',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Sin completar',6,6,'Individual',8,'En curso','2026-11-12 20:34:18'),(238,'Gran Premio Bull · 2da',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Sin completar',6,7,'Individual',8,'En curso','2026-11-12 20:34:20'),(239,'Abierto de Verano Bull · Principiante',NULL,'2026-11-15','18:00:00','2026-11-16',NULL,'Sin completar',6,1,'Individual',8,'Abierto','2026-11-12 20:34:21'),(240,'Abierto de Verano Bull · 6ta',NULL,'2026-11-18','18:00:00','2026-11-19',NULL,'Sin completar',6,3,'Individual',8,'Abierto','2026-11-12 20:34:21'),(241,'Abierto de Verano Bull · 7ta',NULL,'2026-11-21','18:00:00','2026-11-22',NULL,'Sin completar',6,2,'Individual',8,'Abierto','2026-11-12 20:34:21'),(242,'Abierto de Verano Bull · 5ta',NULL,'2026-11-24','18:00:00','2026-11-25',NULL,'Sin completar',6,4,'Individual',8,'Abierto','2026-11-12 20:34:22'),(243,'Desafío de Parejas Bull · 3ra',NULL,'2026-11-27','18:00:00','2026-11-28',NULL,'Sin completar',6,6,'Parejas',8,'Abierto','2026-11-12 20:34:22'),(244,'Copa Primavera hola padel · Principiante',NULL,'2026-10-22','18:00:00','2026-10-23',NULL,'Isla Malvinas',4,1,'Individual',8,'Finalizado','2026-11-12 20:34:32'),(245,'Copa Primavera hola padel · 7ta',NULL,'2026-10-24','18:00:00','2026-10-25',NULL,'Isla Malvinas',4,2,'Individual',9,'Finalizado','2026-11-12 20:34:34'),(246,'Copa Primavera hola padel · 6ta',NULL,'2026-10-26','18:00:00','2026-10-27',NULL,'Isla Malvinas',4,3,'Individual',8,'Finalizado','2026-11-12 20:34:36'),(247,'Copa Primavera hola padel · 5ta',NULL,'2026-10-29','18:00:00','2026-10-30',NULL,'Isla Malvinas',4,4,'Individual',8,'Finalizado','2026-11-12 20:34:38'),(248,'Copa Primavera hola padel · 4ta',NULL,'2026-10-31','18:00:00','2026-11-01',NULL,'Isla Malvinas',4,5,'Individual',8,'Finalizado','2026-11-12 20:34:40'),(249,'Copa Primavera hola padel · 3ra',NULL,'2026-11-02','18:00:00','2026-11-03',NULL,'Isla Malvinas',4,6,'Individual',8,'Finalizado','2026-11-12 20:34:41'),(250,'Copa Primavera hola padel · 2da',NULL,'2026-11-04','18:00:00','2026-11-05',NULL,'Isla Malvinas',4,7,'Individual',8,'Finalizado','2026-11-12 20:34:43'),(251,'Copa Primavera hola padel · 1ra',NULL,'2026-11-07','18:00:00','2026-11-08',NULL,'Isla Malvinas',4,8,'Individual',7,'Finalizado','2026-11-12 20:34:45'),(252,'Dobles Primavera hola padel · 6ta',NULL,'2026-11-09','18:00:00','2026-11-10',NULL,'Isla Malvinas',4,3,'Parejas',8,'Finalizado','2026-11-12 20:34:46'),(253,'Gran Premio hola padel · 5ta',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Isla Malvinas',4,4,'Individual',8,'En curso','2026-11-12 20:35:04'),(254,'Gran Premio hola padel · 2da',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Isla Malvinas',4,7,'Individual',8,'En curso','2026-11-12 20:35:05'),(255,'Gran Premio hola padel · 7ta',NULL,'2026-11-12','18:00:00','2026-11-13',NULL,'Isla Malvinas',4,2,'Individual',8,'En curso','2026-11-12 20:35:07'),(256,'Abierto de Verano hola padel · 7ta',NULL,'2026-11-15','18:00:00','2026-11-16',NULL,'Isla Malvinas',4,2,'Individual',8,'Abierto','2026-11-12 20:35:08'),(257,'Abierto de Verano hola padel · Principiante',NULL,'2026-11-18','18:00:00','2026-11-19',NULL,'Isla Malvinas',4,1,'Individual',8,'Abierto','2026-11-12 20:35:08'),(258,'Abierto de Verano hola padel · 4ta',NULL,'2026-11-21','18:00:00','2026-11-22',NULL,'Isla Malvinas',4,5,'Individual',8,'Abierto','2026-11-12 20:35:09'),(259,'Abierto de Verano hola padel · 6ta',NULL,'2026-11-24','18:00:00','2026-11-25',NULL,'Isla Malvinas',4,3,'Individual',8,'Abierto','2026-11-12 20:35:09'),(260,'Desafío de Parejas hola padel · 2da',NULL,'2026-11-27','18:00:00','2026-11-28',NULL,'Isla Malvinas',4,7,'Parejas',8,'Abierto','2026-11-12 20:35:09');
/*!40000 ALTER TABLE `torneos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
