-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario_club`
--

DROP TABLE IF EXISTS `usuario_club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_club` (
  `id_usuario_club` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_club` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `categoria_estado` enum('Confirmada','Pendiente','Legado') NOT NULL,
  `id_categoria_sugerida` int(11) DEFAULT NULL,
  `fecha_ingreso` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `origen` enum('Migración','Unión al club','Alta manual') NOT NULL DEFAULT 'Unión al club',
  `id_revisor` int(11) DEFAULT NULL,
  `fecha_revision` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario_club`),
  UNIQUE KEY `uk_usuario_club` (`id_usuario`,`id_club`),
  KEY `idx_uc_club_categoria` (`id_club`,`id_categoria`),
  KEY `idx_uc_club_estado` (`id_club`,`categoria_estado`),
  KEY `fk_uc_categoria` (`id_categoria`),
  KEY `fk_uc_sugerida` (`id_categoria_sugerida`),
  KEY `fk_uc_revisor` (`id_revisor`),
  CONSTRAINT `fk_uc_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_uc_club` FOREIGN KEY (`id_club`) REFERENCES `club` (`id_club`),
  CONSTRAINT `fk_uc_revisor` FOREIGN KEY (`id_revisor`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `fk_uc_sugerida` FOREIGN KEY (`id_categoria_sugerida`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_uc_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=505 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_club`
--

LOCK TABLES `usuario_club` WRITE;
/*!40000 ALTER TABLE `usuario_club` DISABLE KEYS */;
INSERT INTO `usuario_club` VALUES (1,49,4,1,'Legado',NULL,'2026-11-11 21:08:58','Migración',NULL,NULL),(242,49,6,1,'Confirmada',NULL,'2026-11-12 12:17:31','Unión al club',NULL,NULL),(377,486,6,1,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(378,486,4,2,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(379,487,6,2,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(380,487,4,1,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(381,488,6,3,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(382,488,4,5,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(383,489,6,5,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(384,489,4,3,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(385,490,6,4,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(386,490,4,6,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(387,491,6,6,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(388,491,4,4,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(389,492,6,7,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(390,492,4,8,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(391,493,6,8,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(392,493,4,7,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(393,494,6,1,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(394,494,4,3,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(395,495,6,4,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(396,495,4,2,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(397,496,6,6,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(398,496,4,8,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(399,497,6,8,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(400,497,4,6,'Confirmada',NULL,'2026-11-12 17:32:26','Unión al club',NULL,NULL),(401,498,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(402,499,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(403,500,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(404,501,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(405,502,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(406,503,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(407,504,6,1,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(408,505,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(409,506,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(410,507,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(411,508,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(412,509,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(413,510,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(414,511,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(415,512,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(416,513,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(417,514,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(418,515,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(419,516,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(420,517,6,2,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(421,518,6,4,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(422,519,6,3,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(423,520,6,4,'Confirmada',NULL,'2026-11-12 17:32:27','Unión al club',NULL,NULL),(424,521,6,4,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(425,522,6,4,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(426,523,6,4,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(427,524,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(428,525,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(429,526,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(430,527,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(431,528,6,4,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(432,529,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(433,530,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(434,531,6,5,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(435,532,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(436,533,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(437,534,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(438,535,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(439,536,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(440,537,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(441,538,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(442,539,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(443,540,6,6,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(444,541,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(445,542,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(446,543,6,7,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(447,544,6,8,'Confirmada',NULL,'2026-11-12 17:32:28','Unión al club',NULL,NULL),(448,545,6,8,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(449,546,6,8,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(450,547,6,7,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(451,548,6,8,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(452,549,6,8,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(453,550,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(454,551,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(455,552,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(456,553,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(457,554,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(458,555,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(459,556,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(460,557,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(461,558,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(462,559,4,1,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(463,560,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(464,561,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(465,562,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(466,563,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(467,564,4,2,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(468,565,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(469,566,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(470,567,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(471,568,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(472,569,4,3,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(473,570,4,4,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(474,571,4,4,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(475,572,4,4,'Confirmada',NULL,'2026-11-12 17:32:29','Unión al club',NULL,NULL),(476,573,4,4,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(477,574,4,4,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(478,575,4,4,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(479,576,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(480,577,4,4,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(481,578,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(482,579,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(483,580,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(484,581,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(485,582,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(486,583,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(487,584,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(488,585,4,5,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(489,586,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(490,587,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(491,588,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(492,589,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(493,590,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(494,591,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(495,592,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(496,593,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(497,594,4,7,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(498,595,4,6,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(499,596,4,8,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(500,597,4,8,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(501,598,4,8,'Confirmada',NULL,'2026-11-12 17:32:30','Unión al club',NULL,NULL),(502,599,4,8,'Confirmada',NULL,'2026-11-12 17:32:31','Unión al club',NULL,NULL),(503,600,4,7,'Confirmada',NULL,'2026-11-12 17:32:31','Unión al club',NULL,NULL),(504,601,4,8,'Confirmada',NULL,'2026-11-12 17:32:31','Unión al club',NULL,NULL);
/*!40000 ALTER TABLE `usuario_club` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
