-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solicitud_cancha`
--

DROP TABLE IF EXISTS `solicitud_cancha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitud_cancha` (
  `id_solicitud_cancha` int(11) NOT NULL AUTO_INCREMENT,
  `id_solicitud` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` enum('Disponible','Ocupada') NOT NULL DEFAULT 'Disponible',
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_solicitud_cancha`),
  KEY `fk_solicitud_cancha` (`id_solicitud`),
  CONSTRAINT `fk_solicitud_cancha` FOREIGN KEY (`id_solicitud`) REFERENCES `solicitud_organizador` (`id_solicitud`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_cancha`
--

LOCK TABLES `solicitud_cancha` WRITE;
/*!40000 ALTER TABLE `solicitud_cancha` DISABLE KEYS */;
INSERT INTO `solicitud_cancha` VALUES (1,2,'Cancha 1','Disponible','img/canchas/cancha_6a7cfb56c92974.96781650.jpg'),(2,2,'Cancha 2','Disponible','img/canchas/cancha_6a7cfb56c93f14.74582006.jpg'),(3,3,'Cancha 1','Disponible','img/canchas/cancha_6a7f94a1673690.14223721.jpg'),(4,3,'Cancha 2','Ocupada','img/canchas/cancha_6a7f94a1680964.53480687.jpg'),(5,4,'Cancha 1','Disponible','img/canchas/cancha_6a7fa049058f77.02818852.jpg'),(6,4,'Cancha 2','Disponible','img/canchas/cancha_6a7fa04905a9f7.36842391.jpg'),(7,5,'Cancha 1','Disponible','img/canchas/cancha_6a88cd53c976f4.42458913.jpg'),(8,6,'Cancha 1','Disponible','img/canchas/cancha_6a88d3091a65b2.20581644.jpg'),(9,7,'Cancha 1','Disponible','img/canchas/cancha_6a88d3988da678.33108080.jpg'),(10,8,'Cancha 1','Disponible','img/canchas/cancha_6a88d6054b9843.54225732.jpg'),(11,9,'Cancha 1','Disponible','img/canchas/cancha_6a8e1c6e899b92.73825760.jpg'),(12,10,'Cancha 1','Disponible','img/canchas/cancha_6a8f753f295548.45641529.jpg');
/*!40000 ALTER TABLE `solicitud_cancha` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
