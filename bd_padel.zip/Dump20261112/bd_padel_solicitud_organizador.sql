-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `solicitud_organizador`
--

DROP TABLE IF EXISTS `solicitud_organizador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solicitud_organizador` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `nombre_club` varchar(100) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `telefono_club` varchar(20) NOT NULL,
  `horario_manana` varchar(50) DEFAULT NULL,
  `horario_tarde` varchar(50) DEFAULT NULL,
  `horario` varchar(100) DEFAULT NULL,
  `cantidad_canchas` int(11) NOT NULL,
  `estado_solicitud` enum('Pendiente','Aceptada','Rechazada') DEFAULT 'Pendiente',
  `fecha_solicitud` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_solicitud`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitud_organizador`
--

LOCK TABLES `solicitud_organizador` WRITE;
/*!40000 ALTER TABLE `solicitud_organizador` DISABLE KEYS */;
INSERT INTO `solicitud_organizador` VALUES (1,'alexis','quiroga','2026-08-13','3443423432','alexisleoneljr3@gmail.com','$2y$10$HzWcQmWMHlfSXqHy/2FOeuBhw99kedZ/9vP/ZWAioiZZXZHTrodXW','dfsdd','Isla Malvinas','543435344354',NULL,NULL,'5545453f',2,'Aceptada','2026-08-11 23:00:39'),(2,'alexis','quiroga','2026-08-08','434242342423432','alexisleoneljr3@gmail.com','$2y$10$d4SiwIj8ae/1SFCXrxY7XOHXYIixAAVLskLC8npI.QXCUiDyP7sve','5434545354','Isla Malvinas','4535453543',NULL,NULL,'4534545435',2,'Aceptada','2026-08-12 23:01:42'),(3,'alexis','quiroga','2026-08-07','34345345345345','alexisleoneljr3@gmail.com','$2y$10$kcvHirtCyrlTcijS4f5Mw.f.ZYmKJnIC8ZmtL0.R8PDKzb0.G5dCi','323123213','Isla Malvinas','323123213123132',NULL,NULL,'2313213213',2,'Rechazada','2026-08-14 22:20:17'),(4,'alexis','quiroga','2026-08-08','4432423432423','alexisleoneljr3@gmail.com','$2y$10$2B27v7W6sauV8G0eRrBZvuqI0ybp1GwJBOQ4HRV6FVFZXyp2F./uC','32323123123','Isla Malvinas','432432432432',NULL,NULL,'434423423432',2,'Rechazada','2026-08-14 23:10:01'),(5,'alexis','quiroga','2008-08-14','4535435345','alexisleoneljr3@gmail.com','$2y$10$QjszzzZFv0Rh4ofkVbC4n.30S4EJADMjCbhuS7MsTMHqu8NHGP.Ii','hola padel','Isla Malvinas','3443424324',NULL,NULL,NULL,1,'Aceptada','2026-08-21 22:12:35'),(6,'alexis','quiroga','2008-08-17','3442434324','alexisleeljr3@gmail.com','$2y$10$puOU95nlnXXhdDi5rIyFkOvmQh1bhEEHeokqkn4gHIym9JtRG2mX2','hola','Isla Malvinas','4234342343',NULL,NULL,NULL,1,'Rechazada','2026-08-21 22:36:57'),(7,'alexis','quiroga','2008-07-30','5432435435','alexisleeljr3@gmail.com','$2y$10$nMNPnpVitAClj8F6/3UrTu9vWRimgzKbMRoPkgr1dd/NicKC.XSoG','hola','Isla Malvinas','4656465465',NULL,NULL,NULL,1,'Rechazada','2026-08-21 22:39:20'),(8,'alexis','quiroga','2008-08-13','4324234324','alexislejr3@gmail.com','$2y$10$AiSWDzObZTxQ5V6xiu9l1OwCWdtdRex2rOkARIg8MOdbHHy49Qlb.','hola padel','Isla Malvinas','4234324243','22:49 - 00:49','23:49 - 20:49',NULL,1,'Rechazada','2026-08-21 22:49:41'),(9,'alexis','quiroga','2008-08-01','3454535435','alexisleoneljr3@gmail.com','$2y$10$MeubXdjUoLFE8GinRQ07YO5V4Ypo2pvlrzeoDyOmIdNwV62LbAU/y','hola padel','Isla Malvinas','4553345334','21:51 - 19:53','19:53 - 21:51',NULL,1,'Aceptada','2026-08-25 22:51:26'),(10,'alexis','quiroga','2008-08-08','4352454554','alxisleoneljr3@gmail.com','$2y$10$/UVs7bgHiRbRqLKGDxmN.ebzrvEYrL4b6Ik5EG48I/8eXe2QEMiRa','club pro','Isla Malvinas','4324242432','22:21 - 20:23','23:21 - 22:25',NULL,1,'Aceptada','2026-08-26 23:22:39');
/*!40000 ALTER TABLE `solicitud_organizador` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
