-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria_historial`
--

DROP TABLE IF EXISTS `categoria_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_historial` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_club` int(11) DEFAULT NULL,
  `id_categoria_anterior` int(11) NOT NULL,
  `id_categoria_nueva` int(11) NOT NULL,
  `tipo` enum('Ascenso por puntos','Cambio administrativo','Descenso por temporada') NOT NULL,
  `motivo` varchar(255) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_torneo` int(11) DEFAULT NULL,
  `id_temporada` int(11) DEFAULT NULL,
  `id_ranking_puntos` int(11) DEFAULT NULL,
  `puntos_alcanzados` int(11) DEFAULT NULL,
  `ultimo_id_ranking_puntos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_historial`),
  UNIQUE KEY `uk_historial_ranking_puntos` (`id_ranking_puntos`),
  KEY `idx_historial_usuario` (`id_usuario`,`id_categoria_nueva`),
  KEY `fk_historial_anterior` (`id_categoria_anterior`),
  KEY `fk_historial_nueva` (`id_categoria_nueva`),
  KEY `fk_historial_torneo` (`id_torneo`),
  KEY `fk_historial_temporada` (`id_temporada`),
  KEY `idx_historial_club_usuario` (`id_club`,`id_usuario`,`id_categoria_nueva`),
  CONSTRAINT `fk_historial_anterior` FOREIGN KEY (`id_categoria_anterior`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_historial_club` FOREIGN KEY (`id_club`) REFERENCES `club` (`id_club`),
  CONSTRAINT `fk_historial_nueva` FOREIGN KEY (`id_categoria_nueva`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_historial_ranking` FOREIGN KEY (`id_ranking_puntos`) REFERENCES `ranking_puntos` (`id_ranking_puntos`),
  CONSTRAINT `fk_historial_temporada` FOREIGN KEY (`id_temporada`) REFERENCES `temporada` (`id_temporada`),
  CONSTRAINT `fk_historial_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`),
  CONSTRAINT `fk_historial_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_historial`
--

LOCK TABLES `categoria_historial` WRITE;
/*!40000 ALTER TABLE `categoria_historial` DISABLE KEYS */;
INSERT INTO `categoria_historial` VALUES (23,498,6,1,2,'Ascenso por puntos','Alcanzó 5030 puntos (límite 5000)','2026-11-12 17:32:39',205,7,2113,5030,2113),(24,494,6,2,1,'Descenso por temporada','Último del ranking de 7ta al finalizar la Temporada 3 (3 puntos, puesto 9 de 9)','2026-11-12 17:33:08',NULL,7,NULL,3,2185),(25,517,6,3,2,'Descenso por temporada','Último del ranking de 6ta al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,2,2185),(26,519,6,4,3,'Descenso por temporada','Último del ranking de 5ta al finalizar la Temporada 3 (604 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,604,2185),(27,528,6,5,4,'Descenso por temporada','Último del ranking de 4ta al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,2,2185),(28,531,6,6,5,'Descenso por temporada','Último del ranking de 3ra al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,2,2185),(29,540,6,7,6,'Descenso por temporada','Último del ranking de 2da al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,2,2185),(30,547,6,8,7,'Descenso por temporada','Último del ranking de 1ra al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:08',NULL,7,NULL,2,2185),(31,550,4,1,2,'Ascenso por puntos','Alcanzó 5030 puntos (límite 5000)','2026-11-12 17:33:17',218,3,2218,5030,2218),(32,559,4,2,1,'Descenso por temporada','Último del ranking de 7ta al finalizar la Temporada 3 (3 puntos, puesto 9 de 9)','2026-11-12 17:33:46',NULL,3,NULL,3,2290),(33,564,4,3,2,'Descenso por temporada','Último del ranking de 6ta al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,2,2290),(34,494,4,4,3,'Descenso por temporada','Último del ranking de 5ta al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,2,2290),(35,577,4,5,4,'Descenso por temporada','Último del ranking de 4ta al finalizar la Temporada 3 (604 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,604,2290),(36,585,4,6,5,'Descenso por temporada','Último del ranking de 3ra al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,2,2290),(37,595,4,7,6,'Descenso por temporada','Último del ranking de 2da al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,2,2290),(38,600,4,8,7,'Descenso por temporada','Último del ranking de 1ra al finalizar la Temporada 3 (2 puntos, puesto 8 de 8)','2026-11-12 17:33:46',NULL,3,NULL,2,2290);
/*!40000 ALTER TABLE `categoria_historial` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
