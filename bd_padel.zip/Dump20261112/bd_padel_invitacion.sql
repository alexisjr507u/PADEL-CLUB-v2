-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `invitacion`
--

DROP TABLE IF EXISTS `invitacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitacion` (
  `id_invitacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_torneo` int(11) NOT NULL,
  `id_inscripcion_invita` int(11) NOT NULL,
  `email_invitado` varchar(100) NOT NULL,
  `id_usuario_invitado` int(11) DEFAULT NULL,
  `estado` enum('Pendiente','Aceptada','Rechazada','Vencida','Cancelada') NOT NULL DEFAULT 'Pendiente',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_vencimiento` timestamp NULL DEFAULT NULL,
  `pendiente_marca` int(11) GENERATED ALWAYS AS (if((`estado` = 'Pendiente'),`id_inscripcion_invita`,NULL)) STORED,
  PRIMARY KEY (`id_invitacion`),
  UNIQUE KEY `uk_invitacion_pendiente_unica` (`pendiente_marca`),
  KEY `fk_invitacion_torneo` (`id_torneo`),
  KEY `fk_invitacion_inscripcion_invita` (`id_inscripcion_invita`),
  KEY `fk_invitacion_usuario_invitado` (`id_usuario_invitado`),
  CONSTRAINT `fk_invitacion_inscripcion_invita` FOREIGN KEY (`id_inscripcion_invita`) REFERENCES `inscripcion` (`id_inscripcion`),
  CONSTRAINT `fk_invitacion_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`),
  CONSTRAINT `fk_invitacion_usuario_invitado` FOREIGN KEY (`id_usuario_invitado`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitacion`
--

LOCK TABLES `invitacion` WRITE;
/*!40000 ALTER TABLE `invitacion` DISABLE KEYS */;
INSERT INTO `invitacion` (`id_invitacion`, `id_torneo`, `id_inscripcion_invita`, `email_invitado`, `id_usuario_invitado`, `estado`, `fecha_creacion`, `fecha_vencimiento`) VALUES (209,208,2474,'nicolas.romero@example.com',520,'Aceptada','2026-11-12 20:32:42','2026-11-19 20:32:42'),(210,208,2476,'belen.gutierrez@example.com',518,'Aceptada','2026-11-12 20:32:47','2026-11-19 20:32:47'),(211,208,2478,'rocio.gomez@example.com',519,'Aceptada','2026-11-12 20:32:51','2026-11-19 20:32:51'),(212,208,2480,'paula.lopez@example.com',521,'Aceptada','2026-11-12 20:32:55','2026-11-19 20:32:55'),(213,222,2587,'esteban.maldonado@example.com',488,'Aceptada','2026-11-12 20:33:22','2026-11-19 20:33:22'),(214,222,2589,'daniela.dominguez@example.com',580,'Aceptada','2026-11-12 20:33:26','2026-11-19 20:33:26'),(215,222,2591,'gonzalo.gonzalez@example.com',577,'Aceptada','2026-11-12 20:33:30','2026-11-19 20:33:30'),(216,222,2593,'valentina.aguirre@example.com',576,'Aceptada','2026-11-12 20:33:34','2026-11-19 20:33:34'),(217,235,2691,'sebastian.silva@example.com',502,'Aceptada','2026-11-12 20:34:00','2026-11-19 20:34:00'),(218,235,2693,'gonzalo.barrios@example.com',494,'Aceptada','2026-11-12 20:34:04','2026-11-19 20:34:04'),(219,235,2695,'gabriela.gonzalez@example.com',499,'Aceptada','2026-11-12 20:34:08','2026-11-19 20:34:08'),(220,235,2697,'lucas.ortiz@example.com',503,'Aceptada','2026-11-12 20:34:12','2026-11-19 20:34:12'),(221,243,2745,'facundo.gomez@example.com',491,'Aceptada','2026-11-12 20:34:22','2026-11-19 20:34:22'),(222,243,2747,'antonella.herrera@example.com',536,'Aceptada','2026-11-12 20:34:26','2026-11-19 20:34:26'),(223,243,2749,'noelia.garcia@example.com',534,'Pendiente','2026-11-12 20:34:30','2026-11-19 20:34:30'),(224,252,2814,'diego.gimenez@example.com',568,'Aceptada','2026-11-12 20:34:46','2026-11-19 20:34:46'),(225,252,2816,'florencia.maldonado@example.com',569,'Aceptada','2026-11-12 20:34:51','2026-11-19 20:34:51'),(226,252,2818,'carolina.figueroa@example.com',565,'Aceptada','2026-11-12 20:34:55','2026-11-19 20:34:55'),(227,252,2820,'gonzalo.barrios@example.com',494,'Aceptada','2026-11-12 20:34:59','2026-11-19 20:34:59'),(228,260,2868,'ramiro.ramirez@example.com',589,'Aceptada','2026-11-12 20:35:09','2026-11-19 20:35:09'),(229,260,2870,'julian.figueroa@example.com',590,'Aceptada','2026-11-12 20:35:13','2026-11-19 20:35:13'),(230,260,2872,'camila.molina@example.com',600,'Pendiente','2026-11-12 20:35:18','2026-11-19 20:35:18');
/*!40000 ALTER TABLE `invitacion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
