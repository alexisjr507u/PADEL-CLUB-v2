-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notificacion`
--

DROP TABLE IF EXISTS `notificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notificacion` (
  `id_notificacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario_destino` int(11) NOT NULL,
  `tipo` enum('invitacion_pendiente','invitacion_aceptada','invitacion_rechazada','invitacion_vencida','inscripcion_aceptada','inscripcion_rechazada','inscripcion_bloqueada','bloqueo_levantado','descalificacion','retiro') NOT NULL,
  `mensaje` varchar(255) NOT NULL,
  `id_torneo` int(11) DEFAULT NULL,
  `id_invitacion` int(11) DEFAULT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT '0',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_notificacion`),
  KEY `fk_notificacion_usuario` (`id_usuario_destino`),
  KEY `fk_notificacion_torneo` (`id_torneo`),
  KEY `fk_notificacion_invitacion` (`id_invitacion`),
  CONSTRAINT `fk_notificacion_invitacion` FOREIGN KEY (`id_invitacion`) REFERENCES `invitacion` (`id_invitacion`),
  CONSTRAINT `fk_notificacion_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`),
  CONSTRAINT `fk_notificacion_usuario` FOREIGN KEY (`id_usuario_destino`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=359 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacion`
--

LOCK TABLES `notificacion` WRITE;
/*!40000 ALTER TABLE `notificacion` DISABLE KEYS */;
INSERT INTO `notificacion` VALUES (317,520,'invitacion_pendiente','Valentina Peralta te invita a formar pareja para participar en el torneo Dobles Apertura Bull · 5ta de The Bull Padel Club.',208,209,1,'2026-11-12 20:32:42'),(318,490,'invitacion_aceptada','Nicolás Romero aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura Bull · 5ta.',208,209,0,'2026-11-12 20:32:45'),(319,518,'invitacion_pendiente','Gonzalo Álvarez te invita a formar pareja para participar en el torneo Dobles Apertura Bull · 5ta de The Bull Padel Club.',208,210,1,'2026-11-12 20:32:47'),(320,522,'invitacion_aceptada','Belén Gutiérrez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura Bull · 5ta.',208,210,0,'2026-11-12 20:32:49'),(321,519,'invitacion_pendiente','Natalia Carrizo te invita a formar pareja para participar en el torneo Dobles Apertura Bull · 5ta de The Bull Padel Club.',208,211,1,'2026-11-12 20:32:51'),(322,495,'invitacion_aceptada','Rocío Gómez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura Bull · 5ta.',208,211,0,'2026-11-12 20:32:53'),(323,521,'invitacion_pendiente','Franco Benítez te invita a formar pareja para participar en el torneo Dobles Apertura Bull · 5ta de The Bull Padel Club.',208,212,1,'2026-11-12 20:32:55'),(324,523,'invitacion_aceptada','Paula López aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura Bull · 5ta.',208,212,0,'2026-11-12 20:32:57'),(325,488,'invitacion_pendiente','Agustina Escobar te invita a formar pareja para participar en el torneo Dobles Apertura hola padel · 4ta de The Bull Padel Club.',222,213,1,'2026-11-12 20:33:22'),(326,579,'invitacion_aceptada','Esteban Maldonado aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura hola padel · 4ta.',222,213,0,'2026-11-12 20:33:24'),(327,580,'invitacion_pendiente','Luciana Castro te invita a formar pareja para participar en el torneo Dobles Apertura hola padel · 4ta de The Bull Padel Club.',222,214,1,'2026-11-12 20:33:26'),(328,582,'invitacion_aceptada','Daniela Domínguez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura hola padel · 4ta.',222,214,0,'2026-11-12 20:33:28'),(329,577,'invitacion_pendiente','Cristian Flores te invita a formar pareja para participar en el torneo Dobles Apertura hola padel · 4ta de The Bull Padel Club.',222,215,1,'2026-11-12 20:33:30'),(330,578,'invitacion_aceptada','Gonzalo González aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura hola padel · 4ta.',222,215,0,'2026-11-12 20:33:32'),(331,576,'invitacion_pendiente','Pablo Cabrera te invita a formar pareja para participar en el torneo Dobles Apertura hola padel · 4ta de The Bull Padel Club.',222,216,1,'2026-11-12 20:33:34'),(332,581,'invitacion_aceptada','Valentina Aguirre aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Apertura hola padel · 4ta.',222,216,0,'2026-11-12 20:33:36'),(333,502,'invitacion_pendiente','Verónica Ibáñez te invita a formar pareja para participar en el torneo Dobles Primavera Bull · Principiante de The Bull Padel Club.',235,217,1,'2026-11-12 20:34:00'),(334,500,'invitacion_aceptada','Sebastián Silva aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera Bull · Principiante.',235,217,0,'2026-11-12 20:34:02'),(335,494,'invitacion_pendiente','Sebastián Cabrera te invita a formar pareja para participar en el torneo Dobles Primavera Bull · Principiante de The Bull Padel Club.',235,218,1,'2026-11-12 20:34:04'),(336,504,'invitacion_aceptada','Gonzalo Barrios aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera Bull · Principiante.',235,218,0,'2026-11-12 20:34:06'),(337,499,'invitacion_pendiente','Joaquín Morales te invita a formar pareja para participar en el torneo Dobles Primavera Bull · Principiante de The Bull Padel Club.',235,219,1,'2026-11-12 20:34:08'),(338,486,'invitacion_aceptada','Gabriela González aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera Bull · Principiante.',235,219,1,'2026-11-12 20:34:10'),(339,503,'invitacion_pendiente','Maximiliano Giménez te invita a formar pareja para participar en el torneo Dobles Primavera Bull · Principiante de The Bull Padel Club.',235,220,1,'2026-11-12 20:34:12'),(340,501,'invitacion_aceptada','Lucas Ortiz aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera Bull · Principiante.',235,220,0,'2026-11-12 20:34:14'),(341,491,'invitacion_pendiente','Martín Aguirre te invita a formar pareja para participar en el torneo Desafío de Parejas Bull · 3ra de The Bull Padel Club.',243,221,1,'2026-11-12 20:34:22'),(342,533,'invitacion_aceptada','Facundo Gómez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Desafío de Parejas Bull · 3ra.',243,221,0,'2026-11-12 20:34:24'),(343,536,'invitacion_pendiente','Natalia Gutiérrez te invita a formar pareja para participar en el torneo Desafío de Parejas Bull · 3ra de The Bull Padel Club.',243,222,1,'2026-11-12 20:34:26'),(344,532,'invitacion_aceptada','Antonella Herrera aceptó tu invitación. Ya están inscriptos como pareja en el torneo Desafío de Parejas Bull · 3ra.',243,222,0,'2026-11-12 20:34:28'),(345,534,'invitacion_pendiente','Nicolás Escobar te invita a formar pareja para participar en el torneo Desafío de Parejas Bull · 3ra de The Bull Padel Club.',243,223,0,'2026-11-12 20:34:30'),(346,568,'invitacion_pendiente','Diego Morales te invita a formar pareja para participar en el torneo Dobles Primavera hola padel · 6ta de The Bull Padel Club.',252,224,1,'2026-11-12 20:34:46'),(347,489,'invitacion_aceptada','Diego Giménez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera hola padel · 6ta.',252,224,0,'2026-11-12 20:34:48'),(348,569,'invitacion_pendiente','Santiago Ibáñez te invita a formar pareja para participar en el torneo Dobles Primavera hola padel · 6ta de The Bull Padel Club.',252,225,1,'2026-11-12 20:34:51'),(349,566,'invitacion_aceptada','Florencia Maldonado aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera hola padel · 6ta.',252,225,0,'2026-11-12 20:34:53'),(350,565,'invitacion_pendiente','Maximiliano Suárez te invita a formar pareja para participar en el torneo Dobles Primavera hola padel · 6ta de The Bull Padel Club.',252,226,1,'2026-11-12 20:34:55'),(351,567,'invitacion_aceptada','Carolina Figueroa aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera hola padel · 6ta.',252,226,0,'2026-11-12 20:34:57'),(352,494,'invitacion_pendiente','Santiago Martínez te invita a formar pareja para participar en el torneo Dobles Primavera hola padel · 6ta de The Bull Padel Club.',252,227,1,'2026-11-12 20:34:59'),(353,563,'invitacion_aceptada','Gonzalo Barrios aceptó tu invitación. Ya están inscriptos como pareja en el torneo Dobles Primavera hola padel · 6ta.',252,227,0,'2026-11-12 20:35:01'),(354,589,'invitacion_pendiente','Martín Molina te invita a formar pareja para participar en el torneo Desafío de Parejas hola padel · 2da de The Bull Padel Club.',260,228,1,'2026-11-12 20:35:09'),(355,591,'invitacion_aceptada','Ramiro Ramírez aceptó tu invitación. Ya están inscriptos como pareja en el torneo Desafío de Parejas hola padel · 2da.',260,228,0,'2026-11-12 20:35:11'),(356,590,'invitacion_pendiente','Cristian Suárez te invita a formar pareja para participar en el torneo Desafío de Parejas hola padel · 2da de The Bull Padel Club.',260,229,1,'2026-11-12 20:35:13'),(357,594,'invitacion_aceptada','Julián Figueroa aceptó tu invitación. Ya están inscriptos como pareja en el torneo Desafío de Parejas hola padel · 2da.',260,229,0,'2026-11-12 20:35:15'),(358,600,'invitacion_pendiente','Agustín Domínguez te invita a formar pareja para participar en el torneo Desafío de Parejas hola padel · 2da de The Bull Padel Club.',260,230,0,'2026-11-12 20:35:18');
/*!40000 ALTER TABLE `notificacion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
