-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bloqueo_inscripcion`
--

DROP TABLE IF EXISTS `bloqueo_inscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bloqueo_inscripcion` (
  `id_bloqueo` int(11) NOT NULL AUTO_INCREMENT,
  `id_torneo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `estado` enum('Activo','Levantado') NOT NULL DEFAULT 'Activo',
  `fecha_bloqueo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ultimo_id_rechazo` int(11) NOT NULL,
  `id_admin_levanta` int(11) DEFAULT NULL,
  `fecha_levantado` datetime DEFAULT NULL,
  `motivo_levantado` varchar(255) DEFAULT NULL,
  `reinicia_conteo` tinyint(1) NOT NULL DEFAULT '0',
  `activo_marca` tinyint(4) GENERATED ALWAYS AS (if((`estado` = 'Activo'),1,NULL)) STORED,
  PRIMARY KEY (`id_bloqueo`),
  UNIQUE KEY `uk_bloqueo_activo` (`id_torneo`,`id_usuario`,`activo_marca`),
  KEY `fk_bloqueo_usuario` (`id_usuario`),
  KEY `fk_bloqueo_admin` (`id_admin_levanta`),
  CONSTRAINT `fk_bloqueo_admin` FOREIGN KEY (`id_admin_levanta`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `fk_bloqueo_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`),
  CONSTRAINT `fk_bloqueo_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bloqueo_inscripcion`
--

LOCK TABLES `bloqueo_inscripcion` WRITE;
/*!40000 ALTER TABLE `bloqueo_inscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloqueo_inscripcion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
