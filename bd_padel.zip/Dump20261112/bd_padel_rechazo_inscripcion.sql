-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rechazo_inscripcion`
--

DROP TABLE IF EXISTS `rechazo_inscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rechazo_inscripcion` (
  `id_rechazo` int(11) NOT NULL AUTO_INCREMENT,
  `id_torneo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_inscripcion` int(11) NOT NULL,
  `id_organizador` int(11) NOT NULL,
  `motivo` varchar(255) NOT NULL,
  `fecha_rechazo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('Vigente','Anulado') NOT NULL DEFAULT 'Vigente',
  `id_admin_anula` int(11) DEFAULT NULL,
  `fecha_anulacion` datetime DEFAULT NULL,
  `motivo_anulacion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_rechazo`),
  KEY `idx_rechazo_torneo_usuario` (`id_torneo`,`id_usuario`,`estado`),
  KEY `fk_rechazo_usuario` (`id_usuario`),
  KEY `fk_rechazo_inscripcion` (`id_inscripcion`),
  KEY `fk_rechazo_organizador` (`id_organizador`),
  KEY `fk_rechazo_admin` (`id_admin_anula`),
  CONSTRAINT `fk_rechazo_admin` FOREIGN KEY (`id_admin_anula`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `fk_rechazo_inscripcion` FOREIGN KEY (`id_inscripcion`) REFERENCES `inscripcion` (`id_inscripcion`),
  CONSTRAINT `fk_rechazo_organizador` FOREIGN KEY (`id_organizador`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `fk_rechazo_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`),
  CONSTRAINT `fk_rechazo_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rechazo_inscripcion`
--

LOCK TABLES `rechazo_inscripcion` WRITE;
/*!40000 ALTER TABLE `rechazo_inscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `rechazo_inscripcion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
