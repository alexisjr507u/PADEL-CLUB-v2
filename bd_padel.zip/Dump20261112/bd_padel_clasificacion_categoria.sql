-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clasificacion_categoria`
--

DROP TABLE IF EXISTS `clasificacion_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clasificacion_categoria` (
  `id_clasificacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `r1` char(1) NOT NULL,
  `r2` char(1) NOT NULL,
  `r3` char(1) NOT NULL,
  `r4` char(1) NOT NULL,
  `r5` char(1) NOT NULL,
  `r6` char(1) NOT NULL,
  `r7` char(1) NOT NULL,
  `r8` char(1) NOT NULL,
  `r9` char(1) NOT NULL,
  `r10` char(1) NOT NULL,
  `version_encuesta` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `puntos_experiencia` tinyint(3) unsigned NOT NULL,
  `puntos_competicion` tinyint(3) unsigned NOT NULL,
  `puntos_tecnica` tinyint(3) unsigned NOT NULL,
  `puntos_tactica` tinyint(3) unsigned NOT NULL,
  `puntos_reglas` tinyint(3) unsigned NOT NULL,
  `puntos_total` tinyint(3) unsigned NOT NULL,
  `id_categoria_estimada` int(11) NOT NULL,
  `motivos` varchar(255) NOT NULL DEFAULT '',
  `fecha_encuesta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `decision` enum('Confirmada','Modificada') DEFAULT NULL,
  `id_categoria_final` int(11) DEFAULT NULL,
  `id_revisor` int(11) DEFAULT NULL,
  `fecha_revision` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_clasificacion`),
  UNIQUE KEY `uq_clasificacion_usuario` (`id_usuario`),
  KEY `fk_clasif_estimada` (`id_categoria_estimada`),
  KEY `fk_clasif_final` (`id_categoria_final`),
  KEY `fk_clasif_revisor` (`id_revisor`),
  CONSTRAINT `fk_clasif_estimada` FOREIGN KEY (`id_categoria_estimada`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_clasif_final` FOREIGN KEY (`id_categoria_final`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `fk_clasif_revisor` FOREIGN KEY (`id_revisor`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `fk_clasif_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clasificacion_categoria`
--

LOCK TABLES `clasificacion_categoria` WRITE;
/*!40000 ALTER TABLE `clasificacion_categoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `clasificacion_categoria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
