-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pareja`
--

DROP TABLE IF EXISTS `pareja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pareja` (
  `id_pareja` int(11) NOT NULL AUTO_INCREMENT,
  `id_torneo` int(11) NOT NULL,
  `id_inscripcion_1` int(11) NOT NULL,
  `id_inscripcion_2` int(11) NOT NULL,
  `fecha_confirmacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pareja`),
  UNIQUE KEY `uk_pareja_inscripcion_1` (`id_inscripcion_1`),
  UNIQUE KEY `uk_pareja_inscripcion_2` (`id_inscripcion_2`),
  KEY `fk_pareja_torneo` (`id_torneo`),
  CONSTRAINT `fk_pareja_inscripcion_1` FOREIGN KEY (`id_inscripcion_1`) REFERENCES `inscripcion` (`id_inscripcion`),
  CONSTRAINT `fk_pareja_inscripcion_2` FOREIGN KEY (`id_inscripcion_2`) REFERENCES `inscripcion` (`id_inscripcion`),
  CONSTRAINT `fk_pareja_torneo` FOREIGN KEY (`id_torneo`) REFERENCES `torneos` (`id_torneo`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pareja`
--

LOCK TABLES `pareja` WRITE;
/*!40000 ALTER TABLE `pareja` DISABLE KEYS */;
INSERT INTO `pareja` VALUES (99,208,2474,2475,'2026-11-12 20:32:45'),(100,208,2476,2477,'2026-11-12 20:32:49'),(101,208,2478,2479,'2026-11-12 20:32:53'),(102,208,2480,2481,'2026-11-12 20:32:57'),(103,222,2587,2588,'2026-11-12 20:33:24'),(104,222,2589,2590,'2026-11-12 20:33:28'),(105,222,2591,2592,'2026-11-12 20:33:32'),(106,222,2593,2594,'2026-11-12 20:33:36'),(107,235,2691,2692,'2026-11-12 20:34:02'),(108,235,2693,2694,'2026-11-12 20:34:06'),(109,235,2695,2696,'2026-11-12 20:34:10'),(110,235,2697,2698,'2026-11-12 20:34:14'),(111,243,2745,2746,'2026-11-12 20:34:24'),(112,243,2747,2748,'2026-11-12 20:34:28'),(113,252,2814,2815,'2026-11-12 20:34:48'),(114,252,2816,2817,'2026-11-12 20:34:53'),(115,252,2818,2819,'2026-11-12 20:34:57'),(116,252,2820,2821,'2026-11-12 20:35:01'),(117,260,2868,2869,'2026-11-12 20:35:11'),(118,260,2870,2871,'2026-11-12 20:35:15');
/*!40000 ALTER TABLE `pareja` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:46
