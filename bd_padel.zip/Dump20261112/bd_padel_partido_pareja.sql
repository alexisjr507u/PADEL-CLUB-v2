-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_padel
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partido_pareja`
--

DROP TABLE IF EXISTS `partido_pareja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partido_pareja` (
  `id_partido` int(11) NOT NULL AUTO_INCREMENT,
  `id_grupo` int(11) DEFAULT NULL,
  `fase` enum('Grupos','Octavos','Cuartos','Semifinal','Final') NOT NULL DEFAULT 'Grupos',
  `orden` int(11) NOT NULL DEFAULT '0',
  `id_entrante_1` int(11) NOT NULL,
  `id_entrante_2` int(11) NOT NULL,
  `set1_games_1` tinyint(3) unsigned DEFAULT NULL,
  `set1_games_2` tinyint(3) unsigned DEFAULT NULL,
  `set2_games_1` tinyint(3) unsigned DEFAULT NULL,
  `set2_games_2` tinyint(3) unsigned DEFAULT NULL,
  `set3_games_1` tinyint(3) unsigned DEFAULT NULL,
  `set3_games_2` tinyint(3) unsigned DEFAULT NULL,
  `id_ganador` int(11) DEFAULT NULL,
  `resultado_tipo` enum('Normal','WO') NOT NULL DEFAULT 'Normal',
  `estado` enum('Pendiente','Jugado') NOT NULL DEFAULT 'Pendiente',
  `fecha_resultado` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_partido`),
  KEY `fk_pp_grupo` (`id_grupo`),
  KEY `fk_pp_e1` (`id_entrante_1`),
  KEY `fk_pp_e2` (`id_entrante_2`),
  KEY `fk_pp_ganador` (`id_ganador`),
  CONSTRAINT `fk_pp_e1` FOREIGN KEY (`id_entrante_1`) REFERENCES `grupo_pareja` (`id_grupo_pareja`),
  CONSTRAINT `fk_pp_e2` FOREIGN KEY (`id_entrante_2`) REFERENCES `grupo_pareja` (`id_grupo_pareja`),
  CONSTRAINT `fk_pp_ganador` FOREIGN KEY (`id_ganador`) REFERENCES `grupo_pareja` (`id_grupo_pareja`),
  CONSTRAINT `fk_pp_grupo` FOREIGN KEY (`id_grupo`) REFERENCES `grupo` (`id_grupo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partido_pareja`
--

LOCK TABLES `partido_pareja` WRITE;
/*!40000 ALTER TABLE `partido_pareja` DISABLE KEYS */;
INSERT INTO `partido_pareja` VALUES (32,574,'Grupos',1,25,26,6,4,6,2,NULL,NULL,25,'Normal','Jugado','2026-11-12 20:32:59'),(33,575,'Grupos',1,27,28,6,3,7,6,NULL,NULL,27,'Normal','Jugado','2026-11-12 20:33:00'),(34,NULL,'Semifinal',1,25,28,7,6,6,4,NULL,NULL,25,'Normal','Jugado','2026-11-12 20:33:00'),(35,NULL,'Semifinal',2,27,26,6,2,6,3,NULL,NULL,27,'Normal','Jugado','2026-11-12 20:33:00'),(36,NULL,'Final',1,25,27,0,6,3,6,NULL,NULL,27,'Normal','Jugado','2026-11-12 20:33:00'),(37,602,'Grupos',1,29,30,6,1,6,2,NULL,NULL,29,'Normal','Jugado','2026-11-12 20:33:39'),(38,603,'Grupos',1,31,32,6,4,6,2,NULL,NULL,31,'Normal','Jugado','2026-11-12 20:33:39'),(39,NULL,'Semifinal',1,29,32,6,2,6,3,NULL,NULL,29,'Normal','Jugado','2026-11-12 20:33:39'),(40,NULL,'Semifinal',2,31,30,6,3,7,6,NULL,NULL,31,'Normal','Jugado','2026-11-12 20:33:39'),(41,NULL,'Final',1,29,31,6,2,4,6,6,4,29,'Normal','Jugado','2026-11-12 20:33:39'),(42,628,'Grupos',1,33,34,6,4,6,4,NULL,NULL,33,'Normal','Jugado','2026-11-12 20:34:16'),(43,629,'Grupos',1,35,36,6,0,6,3,NULL,NULL,35,'Normal','Jugado','2026-11-12 20:34:17'),(44,NULL,'Semifinal',1,33,36,6,4,6,4,NULL,NULL,33,'Normal','Jugado','2026-11-12 20:34:17'),(45,NULL,'Semifinal',2,35,34,6,0,6,3,NULL,NULL,35,'Normal','Jugado','2026-11-12 20:34:17'),(46,NULL,'Final',1,33,35,6,1,6,2,NULL,NULL,33,'Normal','Jugado','2026-11-12 20:34:17'),(47,652,'Grupos',1,37,38,6,1,6,2,NULL,NULL,37,'Normal','Jugado','2026-11-12 20:35:03'),(48,653,'Grupos',1,39,40,6,4,6,2,NULL,NULL,39,'Normal','Jugado','2026-11-12 20:35:03'),(49,NULL,'Semifinal',1,37,40,6,4,6,2,NULL,NULL,37,'Normal','Jugado','2026-11-12 20:35:04'),(50,NULL,'Semifinal',2,39,38,6,3,3,6,6,4,39,'Normal','Jugado','2026-11-12 20:35:04'),(51,NULL,'Final',1,37,39,6,2,6,3,NULL,NULL,37,'Normal','Jugado','2026-11-12 20:35:04');
/*!40000 ALTER TABLE `partido_pareja` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 18:07:47
